#!/usr/bin/env python
# coding: utf-8

# In[62]:


print(type('Привет мир!'))


# In[66]:


print(dir(int))


# In[ ]:





# In[16]:


#при помощи функции мы можем посмотреть все методы класса
print(dir(str))


# Создаем свой первый класс

# In[69]:


class Character:
    pass


# In[ ]:





# Объект - отдельный представитель класса, имеющий конкретное состояние и поведение полностью определяемое классом

# In[71]:


peter = Character()

print(type(peter))


# Атрибуты - переменные внутри класса, которые хранят какую-то информацию о нем.

# In[72]:


# Добавим нашему классу несколько атрибутов
class Character:
    name = ''
    power = 0
    energy = 100
    hands = 2


# In[73]:


#а где хранятся все атрибуты после объявления класса?
Character.__dict__


# In[75]:


#при вызове класса мы всегда создаем новый объект
#у конкретного экземпляра будут все те же атрибуты, что и у его класса
peter = Character()
# print(peter.name)
# print(peter.power)
# print(peter.energy)
# print(peter.hands)

# print(peter.__dict__)


# In[76]:


#мы можем экземпляру присвоить свои атрибуты
peter.name = 'Peter Parker'
peter.power = 70

print(peter.name)
print(peter.power)
print(peter.energy)
print(peter.hands)


# In[77]:


#И даже те, которых изначально в классе нет
peter.alias = 'Spider Man'
print(peter.alias)


# In[78]:


Character.__dict__


# In[79]:


print(peter.name)
print(peter.power)
print(peter.energy)
print(peter.hands)

#изменнные атрибуты же будут храниться в словаре самого экземпляра
print(peter.__dict__)


# In[81]:


#создадим ещё один экземпляр класса
bruce = Character()
bruce.name = 'Bruce Wayne'
bruce.power = 85
bruce.alias = 'Batman'

print(bruce.name)
print(bruce.power)
print(bruce.energy)
print(bruce.hands)
print(bruce.alias)


# In[100]:


class Character:
    name = ''
    power = 0
    energy = 100
    hands = 2
#     back_pack = [] #атрибут с изменяемым типом
#мы видим что аргумент self ссылается на конкретный экземпляр класса(который ещё не создан)
#Его нужно обязательно прописывать, чтобы показать то, что все действия
#будут происходить именно с тем объектом, к которому мы применяем метод

    def eat (self, food):
        if self.energy < 100:
            self.energy += food
        else:
            print('Не голоден')
        
    def do_exercise(self, hours):
        if self.energy > 0:
            self.energy -= hours * 2
            self.power += hours * 2
        else:
            print('Очень устал')
        
    def change_alias(self, new_alias):
        print(self)# смотрим для чего нужен self
        self.alias = new_alias


# In[101]:


# bruce = Character()
# peter = Character()

# peter.back_pack.append('web-shooters')


# In[102]:


# print(peter.back_pack)


# In[103]:


# print(bruce.back_pack)


# In[95]:


#ещё раз проанализируем создание экземпляра
bruce = Character()
bruce.name = 'Bruce Wayne'
bruce.power = 85
bruce.alias = 'Batman'

print(bruce.name)
print(bruce.power)
print(bruce.energy)
print(bruce.hands)


# In[89]:


# пока нет псевдонима
print(bruce.alias)


# In[96]:


# добавим псевдоним
bruce.change_alias('Batman')
print(bruce.alias)


# In[97]:


# Изменим псевдоним
bruce.change_alias('Темный рыцарь')
print(bruce.alias)


# In[99]:


#приступил к тренировке
bruce.do_exercise(1)
print(bruce.power)
print(bruce.energy)
bruce.do_exercise(2)
print(bruce.power)
print(bruce.energy)
bruce.do_exercise(3)
print(bruce.power)
print(bruce.energy)


# In[106]:


class Character:
    def __init__(self, name, power, energy  = 100, hands = 2):
    # параметром по умолчанию back_pack делать не будем, чтобы он не был общим
        self.name = name
        self.power = power
        self.energy = energy
        self.hands = hands
        self.back_pack = [] #будем присваивать пустой список именно для КОНКРЕТНОГО экземпляра при создании его у объекта
#мы видим что аргумент self ссылается на конкретный экземпляр класса(который ещё не создан)
#Его нужно обязательно прописывать, чтобы показать то, что все действия
#будут происходить именно с тем объектом, к которому мы применяем метод

    def eat (self, food):
        if self.energy < 100:
            self.energy += food
        else:
            print('Не голоден')
        
    def do_exercise(self, hours):
        if self.energy > 0:
            self.energy -= hours * 2
            self.power += hours * 2
        else:
            print('Очень устал')
        
    def change_alias(self, new_alias):
        print(self)# смотрим для чего нужен self
        self.alias = new_alias


# In[107]:


# bruce = Character()
# peter = Character()
# теперь при создании экземпляра класса нам нужно обязательно передать аргументы
bruce = Character('Bruce Wayne', 85)
peter = Character('Peter Parker', 70)

print(bruce.name)
print(bruce.power)


print(peter.energy)
print(peter.hands)


# In[108]:


#при таком раскладе (init) все атрибуты сразу же попадают в словарь экземпляра (а не только измененные)
print(peter.__dict__)


# In[109]:


print(Character.__dict__)


# Магический метод init позволяет задать атрибуты при инициализации экземпляра класс, а также решить проблему, указанную выше.

# In[110]:


#так мы решаем проблемы общих изменяемых атрибутов
peter.back_pack.append('web-shooters')


# In[111]:


print(peter.back_pack)
print(bruce.back_pack)


# Итого: в init будем прописывать то, что хотим задавать при инициализации экземпляров класса. Все атрибуты с изменяемыми значениями по-умолчанию, которые по плану будут общие для всех экземпляров можно прописывать без него.

# Взаимодействия классов: посмотрим на основе сложения

# In[119]:


num1 = '5'
num2 = 'jjj'


# In[115]:


# числа являются экземплярами класса int
print(type(num1))
# print(int.__dict__)


# In[120]:


print(num1 + num2)


# In[121]:


#На самом деле происходит следующее
print(num1.__add__(num2))


# In[122]:


class Character:
    def __init__(self, name, power, status = '', energy  = 100, hands = 2):
    # параметром по умолчанию back_pack делать не будем, чтобы он не был общим
        self.name = name
        self.power = power
        self.energy = energy
        self.hands = hands
        self.status = status
        self.back_pack = [] #будем присваивать пустой список именно для КОНКРЕТНОГО экземпляра при создании его у объекта
#мы видим что аргумент self ссылается на конкретный экземпляр класса(который ещё не создан)
#Его нужно обязательно прописывать, чтобы показать то, что все действия
#будут происходить именно с тем объектом, к которому мы применяем метод

    def eat (self, food):
        if self.energy < 100:
            self.energy += food
        else:
            print('Не голоден')
        
    def do_exercise(self, hours):
        if self.energy > 0:
            self.energy -= hours * 2
            self.power += hours * 2
        else:
            print('Очень устал')
        
    def beat_up(self, foe):
        if not isinstance (foe, Character):#проверяем является ли объект экземпляром указанного класса
            return
        if foe.power < self.power:
            foe.status = 'Побежден'
            self.status = 'Победитель'
        else:
            print('Отступил')
            
    def change_alias(self, new_alias):
        print(self)# смотрим для чего нужен self
        self.alias = new_alias


# In[123]:


peter = Character('Peter Parker', 80)
bruce = Character('Bruce Wayne', 85)


# In[124]:


bruce.beat_up(peter)


# In[125]:


print(peter.status)
print(bruce.status)


# In[126]:


peter.beat_up(bruce)


# In[ ]:




